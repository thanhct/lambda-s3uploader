'use strict';
const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const fs = require('fs');
const mime = require('mime-types');
const path = require('path');
const STORE_BUCKET = process.env.STORE_BUCKET;

exports.handler = async (event) => {
    console.log(event);
    let imageData = event.body;
    if (event.isBase64Encoded) {
        imageData = Buffer.from(imageData, 'base64');
    }
    let fileName = event.path.replace('/v1/s3drive/storage', '');
    let params = {
        Body: imageData,
        Bucket: STORE_BUCKET,
        Key: fileName,
        ACL: 'private'
    };

    let data = await putS3(params);
    // TODO implement
    const response = {
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin':'*'

        },
        "statusCode": 200,
        "body": JSON.stringify(data),
        "isBase64Encoded": false
    };
    return response;
};

function putS3(params) {
    return new Promise((resolve, reject) => {
        s3.putObject(params, (error, data) => {
            if (data) {
                resolve(data);
            } else {
                reject(error);
            }

        })

    })
}
